//
//  ViewController.m
//  SampleMacOsApp
//
//  Created by avnish kumar on 29/08/17.
//  Copyright © 2017 avnish kumar. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    NSURL * url = [NSURL URLWithString:@"https://apple.com"];
    NSURLRequest * request = [NSURLRequest requestWithURL:url];
    [self.webView loadRequest:request];
}


- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}


@end
