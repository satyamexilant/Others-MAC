//
//  AppDelegate.h
//  SampleMacOsApp
//
//  Created by avnish kumar on 29/08/17.
//  Copyright © 2017 avnish kumar. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

