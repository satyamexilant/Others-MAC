//
//  ViewController.swift
//  tableviewExample
//
//  Created by avnish kumar on 29/03/16.
//  Copyright © 2016 avnish kumar. All rights reserved.
//

import Cocoa

class ViewController: NSViewController, NSTableViewDataSource, NSTableViewDelegate {

    @IBOutlet weak var tableView: NSTableView!
    let array = ["avnish", "manish", "nishant", "sonu"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.setDelegate(self)
        tableView.setDataSource(self)

        // Do any additional setup after loading the view.
    }

    
    override var representedObject: AnyObject? {
        didSet {
        // Update the view, if already loaded.
        }
    }
    
    
    func numberOfRowsInTableView(tableView: NSTableView) -> Int
    {
        return array.count
    }
    
    
    func tableView(tableView: NSTableView,
        viewForTableColumn tableColumn: NSTableColumn?,
        row: Int) -> NSView?
    {
        let view = tableView.makeViewWithIdentifier("1", owner: self) as! MyCellView
        view.myTableViewCell.stringValue = array[row]
        return view
        
    }
    
    
    
    


}

