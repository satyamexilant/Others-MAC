//
//  MyCellView.swift
//  tableviewExample
//
//  Created by avnish kumar on 29/03/16.
//  Copyright © 2016 avnish kumar. All rights reserved.
//

import Cocoa

class MyCellView: NSTableCellView {

    override func drawRect(dirtyRect: NSRect) {
        super.drawRect(dirtyRect)

        // Drawing code here.
    }
    
    
    @IBAction func myButton(sender: AnyObject) {
        
        Swift.print("hello")
    }
    
    
    @IBOutlet weak var myTableViewCell: NSTextField!
}
