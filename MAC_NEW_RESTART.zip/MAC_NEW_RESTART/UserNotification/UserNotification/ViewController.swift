//
//  ViewController.swift
//  UserNotification
//
//  Created by medidi vv satyanarayana murty on 14/12/16.
//  Copyright © 2016 Medidi  V V  Satyanarayana Murty. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    @IBOutlet var empID: NSTextField!
    @IBOutlet var name: NSTextField!
    @IBOutlet var label: NSTextField!
    @IBOutlet var label1: NSTextField!
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }

    @IBAction func display(_ sender: AnyObject) {
        // Get the path to the current user's Downloads folder
        let downloadsFolder = NSHomeDirectory() + "/Downloads/"
        
        //Use the value of the nameField to give the output file a name
        let fileName = downloadsFolder + ".txt"
        
        //Use the value of the messageField for the contents of the text file
        let contents = empID.stringValue
        
        do {
            // write the contents to a text file in the downloads folder
            try contents.write(toFile: fileName, atomically: true, encoding: String.Encoding.utf8)
            
            // create a User Notification
            let notification = NSUserNotification.init()
            
            // set the title and the informative text
            
            notification.title = name.stringValue
        
            notification.informativeText = empID.stringValue
            
            // put the path to the created text file in the userInfo dictionary of the notification
            notification.userInfo = ["path" : fileName]
            
            // use the default sound for a notification
            notification.soundName = NSUserNotificationDefaultSoundName
            
            // if the user chooses to display the notification as an alert, give it an action button called "View"
            notification.hasActionButton = true
            notification.actionButtonTitle = "View"
            self.label.stringValue = self.name.stringValue
            self.label1.stringValue  = self.empID.stringValue
            // Deliver the notification through the User Notification Center
            NSUserNotificationCenter.default.deliver(notification)
            
        } catch {
            print(error)
        }

    }

}

