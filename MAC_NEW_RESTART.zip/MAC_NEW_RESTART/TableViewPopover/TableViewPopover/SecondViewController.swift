//
//  SecondViewController.swift
//  TableViewPopover
//
//  Created by medidi vv satyanarayana murty on 14/12/16.
//  Copyright © 2016 Medidi  V V  Satyanarayana Murty. All rights reserved.
//

import Cocoa

class SecondViewController: NSWindowController
{
    
    override func windowDidLoad()
    {
        super.windowDidLoad()
    }
    
    @IBAction func back(_ sender: AnyObject) {
        
       
    }
}
