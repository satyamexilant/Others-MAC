//
//  ThirdViewController.swift
//  TableViewPopover
//
//  Created by medidi vv satyanarayana murty on 14/12/16.
//  Copyright © 2016 Medidi  V V  Satyanarayana Murty. All rights reserved.
//

import Cocoa

class ThirdViewController: NSWindowController,NSWindowDelegate {
    var fo:FourthViewController?
    override func windowDidLoad() {
        super.windowDidLoad()

        
    }
    
    @IBAction func gfg(_ sender: AnyObject) {
        
        fo = FourthViewController(windowNibName: "FourthViewController")
        fo?.window?.beginSheet((fo?.window!)!, completionHandler: nil)
        
    }
}
