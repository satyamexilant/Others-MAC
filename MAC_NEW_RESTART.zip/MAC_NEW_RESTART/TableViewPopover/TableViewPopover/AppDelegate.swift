//
//  AppDelegate.swift
//  TableViewPopover
//
//  Created by medidi vv satyanarayana murty on 14/12/16.
//  Copyright © 2016 Medidi  V V  Satyanarayana Murty. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {



    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }


}

