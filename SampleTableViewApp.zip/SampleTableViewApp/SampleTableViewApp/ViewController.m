//
//  ViewController.m
//  TableViewPlistData
//
//  Created by medidi vv satyanarayana murty on 29/08/17.
//  Copyright © 2017 medidi vv satyanarayana murty. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController 

 
- (void)viewDidLoad {
    [super viewDidLoad];

    NSString *path = [[NSBundle mainBundle] pathForResource:@"EmployeeData" ofType:@"plist"];
    NSMutableDictionary *dictOfEmployee = [NSMutableDictionary dictionaryWithContentsOfFile:path];
    
    if (dictOfEmployee[@"Employees"] != nil) {
        
        self.dataArray = dictOfEmployee[@"Employees"];
    }
}


- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}

- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView {
    
    return  self.dataArray.count;
}

- (NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row {
    
    if ([tableColumn.identifier  isEqual: @"0"]) {
        
        NSTableCellView *view = [tableView makeViewWithIdentifier:@"EmployeeIDCell" owner:self];
        view.textField.stringValue = self.dataArray[row][@"Employee ID"];
        return view;
    }else if ([tableColumn.identifier  isEqual: @"1"]){
        NSTableCellView *view = [tableView makeViewWithIdentifier:@"EmployeeNameCell" owner:self];
        view.textField.stringValue = view.textField.stringValue = self.dataArray[row][@"Employee Name"];;
        return view;
    }else{
        NSTableCellView *view = [tableView makeViewWithIdentifier:@"EmployeeContactNoCell" owner:self];
        view.textField.stringValue = view.textField.stringValue = self.dataArray[row][@"Contact no"];;
        return view;
    }
   
   
}

@end
